# HDB Price API

FastAPI backend for Singapore HDB resale price data.

## Setup
1. Clone repo
2. Copy `.env.example` to `.env`
3. Set Supabase credentials
4. `pip install -r requirements.txt`
5. `uvicorn app.main:app --reload`

## Deployment
- Connected to Render.com
- Auto-deploys on git push to main