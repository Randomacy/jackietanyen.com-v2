from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from supabase import create_client
import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="HDB Price API",
    description="Singapore HDB Resale Price API",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Supabase client
supabase = create_client(
    os.getenv('SUPABASE_URL'),
    os.getenv('SUPABASE_KEY')
)

@app.get("/")
async def root():
    return {"message": "HDB Price API", "status": "active"}

@app.get("/api/v1/prices")
async def get_prices(
    town: str,
    flat_type: Optional[str] = None,
    flat_model: Optional[str] = None,
    start_month: Optional[str] = None,   # YYYY-MM-01
    end_month: Optional[str] = None      # YYYY-MM-01 (exclusive)
):
    payload = {
        "p_town_name": town,
        "p_flat_type": flat_type,
        "p_flat_model": flat_model,
        "p_start_month": start_month,
        "p_end_month": end_month,
    }
    res = supabase.rpc("get_town_stats", payload).execute()
    if not res.data:
        raise HTTPException(status_code=404, detail="No matching transactions.")
    row = res.data[0]
    return {
        "town": row["town"],
        "flat_type": row["flat_type"],
        "flat_model": row["flat_model"],
        "transaction_count": row["txn_count"],
        "average_price": float(row["avg_price"]) if row["avg_price"] is not None else None,
        "min_price": float(row["min_price"]) if row["min_price"] is not None else None,
        "max_price": float(row["max_price"]) if row["max_price"] is not None else None,
        "p50": float(row["p50"]) if row["p50"] is not None else None,
        "p90": float(row["p90"]) if row["p90"] is not None else None,
        "first_month": row["first_month"],
        "last_month": row["last_month"],
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)